mydata <- read.csv("FeatureVector5.csv", sep = ',', header = TRUE)
library(caret)
library(mlbench)
library(gbm)
mydata$Label = as.numeric(mydata$Label)
gbm.model = gbm(Label~., data=mydata, shrinkage=0.01, distribution = 'bernoulli', cv.folds=5, n.trees=3000, verbose=F)
best.iter = gbm.perf(gbm.model, method="cv")


set.seed(123)
fitControl = trainControl(method="cv", number=5, returnResamp = "all")
mydata$Label = as.factor(mydata$Label)
model = train(Label~., data=mydata, method="gbm",distribution="bernoulli", trControl=fitControl, verbose=F, 
               tuneGrid=data.frame(.n.trees=best.iter, .shrinkage=0.01, .interaction.depth=1, .n.minobsinnode=1))
confusionMatrix(model)
