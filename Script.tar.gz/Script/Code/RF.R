mydata <- read.csv("FeatureVector5.csv", sep = ',', header = TRUE)
#mydata <- mydata[,-1]
mydata$Label = as.factor(mydata$Label)
library(randomForest)
set.seed(71) 
rf <-randomForest(Label~.,data=mydata, ntree=1500) 
print(rf)
