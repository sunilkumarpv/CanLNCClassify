library(caret)
library(ggplot2)
library(mlbench)
library(pROC)
#library(plotROC)

lnc_df <- read.csv("featureset.csv", sep = ',', header = FALSE)
set.seed(3038)
intrain <- createDataPartition(y = lnc_df$V9, p= 0.6, list = FALSE)
training <- lnc_df[intrain,]
testing <- lnc_df[-intrain,]
training[["V9"]] = factor(training[["V9"]])

trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3, classProbs=T,savePredictions = T)
svm_Linear <- train(V9 ~., data = training, method = "svmLinear",
                    trControl=trctrl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10)
test_pred <- predict(svm_Linear, newdata = testing, type = "raw")

gc_prob <- predict(svm_Linear, newdata = testing, type = "prob")

gc_pROC <- roc(response = testing$V9, predictor = gc_prob[, "Second"])
plot(gc_pROC) #legacy.axes = TRUE)
gc_pROC$auc
