LL <- as.matrix(readRDS("LL_AdjMat.Rda"))
LP <- as.matrix(readRDS("LP_AdjMat.Rda"))
PL <- as.matrix(readRDS("PL_AdjMat.Rda"))
PP <- as.matrix(readRDS("PP_AdjMat.Rda"))

lncrnas <- as.data.frame(rownames(LL))
proteins <- as.data.frame(rownames(PL))
paths <- c("LPL",	"LLPL",	"LPPL",	"LLPLL",	"LPLLL",	"LPLPL",	"LPPLL",	"LPPPL")

fv <- data.frame(matrix(nrow = 129, ncol =8))
rownames(fv) <- lncrnas[,1]
colnames(fv) <- paths

prod <- matrix(nrow = 129,ncol = 129)
colno <- 1

for(i in paths){
  prod <- eval(parse(text = substr(i,1,2)))
  j <- 2
    while(j < nchar(i)){
      prod <- prod %*% eval(parse(text = substr(i,j,j+1)))
      j <- j+1
    }
  rsum <- as.data.frame(rowSums(prod))
  fv[,colno] <- rsum[,1]
  colno <- colno+1
}
write.csv(fv,"FeatureVector.csv")