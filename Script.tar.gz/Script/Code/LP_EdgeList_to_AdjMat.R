# LncRNA - Protein Adjacency Matrix

Plist <- read.csv("Protein_list.csv",header = TRUE,sep=',')
Llist <- read.csv("LncRNA_List.csv",header = TRUE,sep=',')

LP_AdjMat <- data.frame(matrix(ncol = 2646, nrow = 129))
colnames(LP_AdjMat) <- Plist$Proteins
LP_AdjMat[,1] <- Llist[,1]
rownames(LP_AdjMat)  <- LP_AdjMat[,1]
LP_AdjMat[,1] <- NA
LP_AdjMat[is.na(LP_AdjMat)] <- 0

links <- read.csv("LPI_Final.csv",header = TRUE,sep=',')

for(i in 1:nrow(links))
{
  LP_AdjMat[matrix(links$ncName[i]),matrix(links$InteractionPartner[i])]=1
}
saveRDS(LP_AdjMat, file="LP_AdjMat.Rda")

#Protein-LncRNA Adjacency Matrix

library(data.table)
PL_AdjMat <- transpose(LP_AdjMat)
colnames(PL_AdjMat) <- rownames(LP_AdjMat)
rownames(PL_AdjMat) <- colnames(LP_AdjMat)
saveRDS(PL_AdjMat, file="PL_AdjMat.Rda")

#col = colnames(z)[apply(z, 2, function(u) any(u==FALSE))] ; to find all colummns with FALSE.

