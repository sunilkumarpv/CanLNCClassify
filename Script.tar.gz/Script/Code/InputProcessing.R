
# Processing NpInter

LL <- read.csv("interaction_NPInter[v3.0].csv",header = TRUE,sep=',') 
LL<-subset(LL, grepl("NONHSAG", ncIdentifier)) # remove all rowus without 'NONHSAG' pattern in NONCODE id column (make human alone)
patterns <- c("UniGene", "UniProt")
LL<-subset(LL, grepl(paste(patterns, collapse = "|"), prType))  # remove all non protein rows (only proteins from Uniprot or Unigene are retained)
LL <- LL[!duplicated(LL[c('ncName', 'InteractionPartner')]),] # remove dulpicate rows if lncRNA column ('ncName') and protein column('InteractionPartner') simultaneousely have same values 
write.csv(LL, file = "interaction_NPInter_human_lnc_protein.csv") 

#processing Lnc2Cancer

LL <- read.csv("lnc2cancer.csv",header = TRUE,sep=',') 
LL <- LL[!duplicated(LL['LncRNA.name']),] #remove dupplicates based on 'lncRNA.name' column
write.csv(LL, file = "lnc2cancer_nodup.csv")

#To drop those lncRNAs in NpInter that are not present in Lnc2Cancer

df1 <- read.csv("interaction_NPInter_human_lnc_protein.csv",header = TRUE,sep=',')
df2 <- read.csv("lnc2cancer_nodup.csv",header = TRUE,sep=',') 
df3 <- df1[df1$ncName %in% df2$LncRNA.name,]
write.csv(df3, file = "npinter_lnc2cancer_common.csv")

#interactions from starBase are incorporated manually to make a file "NpInter_starBase.csv" (This creates new duplicates)

df1 <- read.csv("NpInter_starBase.csv",header = TRUE,sep=',')

#remove duplicates again

df1 <- df1[!duplicated(df1[c('ncName', 'InteractionPartner')]),] # remove dulpicate rows if lncRNA column ('ncName') and protein column('InteractionPartner') simultaneousely have same values 
write.csv(df1, file = "LPI1.csv")
