Plist <- read.csv("Protein_list.csv",header = TRUE,sep=',')
PP_AdjMat <- data.frame(matrix(ncol = 2646, nrow = 2646))
colnames(PP_AdjMat) <- Plist$Proteins
PP_AdjMat[,1] <- Plist[,1]
rownames(PP_AdjMat)  <- PP_AdjMat[,1]
PP_AdjMat[,1] <- NA
PP_AdjMat[is.na(PP_AdjMat)] <- 0

links <- read.csv("string_PPI.csv",header = TRUE,sep=',')
for(i in 1:nrow(links))
{
  PP_AdjMat[matrix(links$X.node1[i]),matrix(links$node2[i])]=1
}

saveRDS(PP_AdjMat, file="PP_AdjMat.Rda")
