# From LPI a file with NONCODE id and name is created manually and read
LL <- read.csv("LncRNAsIdName.csv",header = TRUE,sep=',') 
LL <- LL[!duplicated(LL['ncName']),] # duplicates are removed
write.csv(LL, file = "LncRNAsIdNameNodup.csv")
NON <- read.csv("NONCODE.csv",header = TRUE,sep=',') 
LL <- LL[LL$ncIdentifier %in% NON$NONCODE.ID,] # LncRNAs not in NONCODE are dropped
write.csv(LL, file = "LPI_NONCODE_Common.csv")
NON1 <- NON[NON$NONCODE.ID %in% LL$ncIdentifier,]
write.csv(NON1, file = "NONCODE_LPI_Common.csv")
