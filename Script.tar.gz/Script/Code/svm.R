library(caret)
lnc_df <- read.csv("starBaseFeatureVectorKnown.csv", sep = ',', header = FALSE)
set.seed(3033)
intrain <- createDataPartition(y = lnc_df$V9, p= 0.3, list = FALSE)
training <- lnc_df[intrain,]
testing <- lnc_df[-intrain,]
training[["V9"]] = factor(training[["V9"]])
trctrl <- trainControl(method = "repeatedcv", number = 10, repeats = 3)
set.seed(3233)

svm_Linear <- train(V9 ~., data = training, method = "svmLinear",
                    trControl=trctrl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10)
test_pred <- predict(svm_Linear, newdata = testing)


svm_Linear
confusionMatrix(test_pred, testing$V9 )
