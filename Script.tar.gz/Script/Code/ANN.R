mydata <- read.csv("FeatureVector.csv", sep = ',', header = TRUE)
mydata <- mydata[,-1]
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x)))
}
maxmindf <- as.data.frame(lapply(mydata, normalize))
trainset <- maxmindf[1:86, ]
testset <- maxmindf[87:107, ]
feats <- names(maxmindf)
feats <- feats[-1]
f <- paste(feats,collapse=' + ')
f <- paste('Label ~',f)
f <- as.formula(f)
#Training
library(neuralnet)
nn <- neuralnet(f,trainset,hidden=c(10,10,10),linear.output=FALSE,threshold=0.01)
nn$result.matrix
plot(nn)
#Testing
temp_test <- subset(testset , select =-(Label))
nn.results <- compute(nn, temp_test)
results <- data.frame(actual = testset$Label, prediction = nn.results$net.result)
roundedresults<-sapply(results,round,digits=0)
roundedresultsdf=data.frame(roundedresults)
attach(roundedresultsdf)
table(actual,prediction)