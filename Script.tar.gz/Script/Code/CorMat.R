#Store the coexpression values in .csv format in the working directory
MyData <- read.csv("Profile_Final.csv",header = TRUE,sep=',')
names <- as.data.frame(MyData[,1])
MyData <- MyData[,-1] #Remove column 1(LncRna Name)
CorMat <- cor(t(MyData))#cormat calculates columnwise correlation of any matrix. So transpose is taken as 't(Mydata)'
CorMat[is.na(CorMat)] <- 0
c <- CorMat

CorMat[CorMat == 1] = 0 # All diagonal elements to 0, no loops
CorMat[CorMat <= 0] = 0 #Correlation coefficient <= 0 means no edge
CorMat[CorMat > 0] = 1

CorMat <- as.data.frame(CorMat)
colnames(CorMat) <- names[,1]
rownames(CorMat) <- names[,1]

saveRDS(CorMat, file="LL_AdjMat.Rda")

#write.csv(CorMat, file = "CorrelationMatrix.csv")